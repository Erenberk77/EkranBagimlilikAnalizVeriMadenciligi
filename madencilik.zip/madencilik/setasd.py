import pandas as pd
import numpy as np
import plotly.express as px 
import plotly.graph_objects as go
import statsmodels.api as sm


data = pd.read_csv('Screentime-App-Details1.csv')  

#print(data.describe())

"""figure = px.bar(data_frame=data, x="Date", y="Usage", color="App", title="Screen Time Analysis")
figure.show()"""

"""figure = px.area(data_frame=data, x="Date", y="Usage", color="App", title="Screen Time Analysis")
figure.show()"""

"""figure = px.pie(data_frame=data, values="Usage", names="App", title="Screen Time Analysis")
figure.show()"""

"""figure = px.ecdf(data_frame=data, x="Usage", color="App", title="Screen Time Analysis")
figure.show()"""


# Her bir uygulama için günlük toplam kullanım sürelerini hesaplama
instagram_data = data[data['App'] == 'Instagram']
whatsapp_data = data[data['App'] == 'Whatsapp']
pubg_data = data[data['App'] == 'Pubg']
tiktok_data = data[data['App'] == 'Tiktok']
twitter_data = data[data['App'] == 'Twitter']

# Günlük toplam kullanım sürelerini hesaplama
instagram_daily_usage = instagram_data.groupby('Date')['Usage'].sum()
whatsapp_daily_usage = whatsapp_data.groupby('Date')['Usage'].sum()
pubg_daily_usage = pubg_data.groupby('Date')['Usage'].sum()
tiktok_daily_usage = tiktok_data.groupby('Date')['Usage'].sum()
twitter_daily_usage = twitter_data.groupby('Date')['Usage'].sum()

# Bağımlılık değerlendirmesi için kullanım sürelerini toplamak
total_instagram_usage = instagram_daily_usage.sum()
total_whatsapp_usage = whatsapp_daily_usage.sum()
total_pubg_usage = pubg_daily_usage.sum()
total_tiktok_usage = tiktok_daily_usage.sum()
total_twitter_usage = twitter_daily_usage.sum()

yas = int(input("Lütfen yaşınızı girin: "))
yas=int(yas)

if yas < 10:
    instagram_threshold = 3000   # Instagram kullanımı için bağımlılık eşik değeri
    whatsapp_threshold = 3000  # Whatsapp kullanımı için bağımlılık eşik değeri
    pubg_threshold = 3000  # Pubg kullanımı için bağımlılık eşik değeri
    tiktok_threshold = 3000  # Tiktok kullanımı için bağımlılık eşik değeri
    twitter_threshold = 3000  # Twitter kullanımı için bağımlılık eşik değeri
elif yas >= 10 and yas < 35:
    instagram_threshold = 5000   # Instagram kullanımı için bağımlılık eşik değeri
    whatsapp_threshold = 3500  # Whatsapp kullanımı için bağımlılık eşik değeri
    pubg_threshold = 3500  # Pubg kullanımı için bağımlılık eşik değeri
    tiktok_threshold = 3500  # Tiktok kullanımı için bağımlılık eşik değeri
    twitter_threshold = 3500  # Twitter kullanımı için bağımlılık eşik değeri
elif yas >= 35:
    instagram_threshold = 3500   # Instagram kullanımı için bağımlılık eşik değeri
    whatsapp_threshold = 3500  # Whatsapp kullanımı için bağımlılık eşik değeri
    pubg_threshold = 3500  # Pubg kullanımı için bağımlılık eşik değeri
    tiktok_threshold = 3500  # Tiktok kullanımı için bağımlılık eşik değeri
    twitter_threshold = 3500  # Twitter kullanımı için bağımlılık eşik değeri

# İlk 15 gün ve son 12 gün için verileri ayırma
instagram_first_30_days = instagram_data.head(30)
instagram_last_30_days = instagram_data.tail(30)

whatsapp_first_30_days = whatsapp_data.head(30)
whatsapp_last_30_days = whatsapp_data.tail(30)

pubg_first_30_days = pubg_data.head(30)
pubg_last_30_days = pubg_data.tail(30)

tiktok_first_30_days = tiktok_data.head(30)
tiktok_last_30_days = tiktok_data.tail(30)

twitter_first_30_days = twitter_data.head(30)
twitter_last_30_days = twitter_data.tail(30)

# İlk 15 gün ve son 12 gün için ortalama kullanım sürelerini hesaplama
instagram_avg_first_30_days = instagram_first_30_days['Usage'].mean()
instagram_avg_last_30_days = instagram_last_30_days['Usage'].mean()

whatsapp_avg_first_30_days = whatsapp_first_30_days['Usage'].mean()
whatsapp_avg_last_30_days = whatsapp_last_30_days['Usage'].mean()

tiktok_avg_first_30_days = tiktok_first_30_days['Usage'].mean()
tiktok_avg_last_30_days = tiktok_last_30_days['Usage'].mean()

pubg_avg_first_30_days = pubg_first_30_days['Usage'].mean()
pubg_avg_last_30_days = pubg_last_30_days['Usage'].mean()

twitter_avg_first_30_days = twitter_first_30_days['Usage'].mean()
twitter_avg_last_30_days = twitter_last_30_days['Usage'].mean()

# Kullanıcı bağımlılık değerlendirmesi
is_instagram_addict = total_instagram_usage > instagram_threshold
is_whatsapp_addict = total_whatsapp_usage > whatsapp_threshold
is_pubg_addict = total_pubg_usage > pubg_threshold
is_tiktok_addict = total_tiktok_usage > tiktok_threshold
is_twitter_addict = total_twitter_usage > twitter_threshold


if yas < 10:
    is_between_thresholds_instagram = total_instagram_usage > 2500 and total_instagram_usage < 3000
elif yas >= 10 and yas <35:
    is_between_thresholds_instagram = total_instagram_usage > 3500 and total_instagram_usage < 4000
elif yas >= 35:
    is_between_thresholds_instagram = total_instagram_usage > 3000 and total_instagram_usage < 3500

if yas < 10:
    is_between_thresholds_whatsapp = total_whatsapp_usage > 2500 and total_whatsapp_usage < 3000
elif yas >= 10 and yas <35:
    is_between_thresholds_whatsapp = total_whatsapp_usage > 3500 and total_whatsapp_usage < 4000
elif yas >= 35:
    is_between_thresholds_whatsapp = total_whatsapp_usage > 3000 and total_whatsapp_usage < 3500

if yas < 10:
    is_between_thresholds_pubg = total_pubg_usage > 2500 and total_pubg_usage < 3000
elif yas >= 10 and yas <35:
    is_between_thresholds_pubg = total_pubg_usage > 3500 and total_pubg_usage < 4000
elif yas >= 35:
    is_between_thresholds_pubg = total_pubg_usage > 3000 and total_pubg_usage < 3500

if yas < 10:
    is_between_thresholds_tiktok = total_tiktok_usage > 2500 and total_tiktok_usage < 3000
elif yas >= 10 and yas <35:
    is_between_thresholds_tiktok = total_tiktok_usage > 3500 and total_tiktok_usage < 4000
elif yas >= 35:
    is_between_thresholds_tiktok = total_tiktok_usage > 3000 and total_tiktok_usage < 3500
    
if yas < 10:
    is_between_thresholds_twitter = total_twitter_usage > 2500 and total_twitter_usage < 3000
elif yas >= 10 and yas <35:
    is_between_thresholds_twitter = total_twitter_usage > 3500 and total_twitter_usage < 4000
elif yas >= 35:
    is_between_thresholds_twitter = total_twitter_usage > 3000 and total_twitter_usage < 3500

# Sonuçları yazdırma
print("Toplam Instagram Kullanım Süresi:", total_instagram_usage)
print("Toplam Whatsapp Kullanım Süresi:", total_whatsapp_usage)
print("Toplam Pubg Kullanım Süresi:", total_pubg_usage)
print("Toplam Tiktok Kullanım Süresi:", total_tiktok_usage)
print("Toplam Twitter Kullanım Süresi:", total_twitter_usage)

if is_instagram_addict:
    print("Kullanıcı Instagram'a bağımlı.")
else:
    print("Kullanıcı Instagram'a bağımlı değil.")

if is_whatsapp_addict:
    print("Kullanıcı Whatsapp'a bağımlı.")
else:
    print("Kullanıcı Whatsapp'a bağımlı değil.")
    
if is_pubg_addict:
    print("Kullanıcı Pubg'ye bağımlı.")
else:
    print("Kullanıcı Pubg'ye bağımlı değil.")
    
if is_tiktok_addict:
    print("Kullanıcı Tiktok'a bağımlı.")
else:
    print("Kullanıcı Tiktok'a bağımlı değil.")
    
if is_twitter_addict:
    print("Kullanıcı Twitter'a bağımlı.")
else:
    print("Kullanıcı Twitter'a bağımlı değil.")

if is_between_thresholds_instagram:
    print("Kullanıcı için dikkat edilmesi gereken Instagram kullanım süresi aralığında." , total_instagram_usage, "dk kullanılmıştır. ")

if is_between_thresholds_whatsapp:
    print("Kullanıcı için dikkat edilmesi gereken Whatsapp kullanım süresi aralığında." , total_whatsapp_usage, "dk kullanılmıştır. ")
    
if is_between_thresholds_pubg:
    print("Kullanıcı için dikkat edilmesi gereken Pubg kullanım süresi aralığında." , total_pubg_usage, "dk kullanılmıştır. ")
    
if is_between_thresholds_tiktok:
    print("Kullanıcı için dikkat edilmesi gereken Tiktok kullanım süresi aralığında." , total_tiktok_usage, "dk kullanılmıştır. ")

if is_between_thresholds_twitter:
    print("Kullanıcı için dikkat edilmesi gereken Twitter kullanım süresi aralığında." , total_twitter_usage, "dk kullanılmıştır. ")

# Bağımlılık durumu değerlendirmesi
if instagram_avg_first_30_days > instagram_avg_last_30_days:
    print("Kullanıcının Instagram kullanımı son 30 günde azaltmıştır.")
else:
    print("Kullanıcının Instagram kullanımı son 30 günde artmıştır. Kullanım süresine dikkat etmelidir.")

if whatsapp_avg_first_30_days > whatsapp_avg_last_30_days:
    print("Kullanıcının Whatsapp kullanımı son 30 günde azaltmıştır.")
else:
   print("Kullanıcının Whatsapp kullanımı son 30 günde artmıştır. Kullanım süresine dikkat etmelidir.")
   
if pubg_avg_first_30_days > pubg_avg_last_30_days:
    print("Kullanıcının Pubg kullanımı son 30 günde azaltmıştır.")
else:
    print("Kullanıcının Pubg kullanımı son 30 günde artmıştır. Kullanım süresine dikkat etmelidir.")
    
if tiktok_avg_first_30_days > tiktok_avg_last_30_days:
    print("Kullanıcının Tiktok kullanımı son 30 günde azaltmıştır.")
else:
    print("Kullanıcının Tiktok kullanımı son 30 günde artmıştır. Kullanım süresine dikkat etmelidir.")
    
if twitter_avg_first_30_days > twitter_avg_last_30_days:
    print("Kullanıcının Twitter kullanımı son 30 günde azaltmıştır.")
else:
    print("Kullanıcının Twitter kullanımı son 30 günde artmıştır. Kullanım süresine dikkat etmelidir.")
    